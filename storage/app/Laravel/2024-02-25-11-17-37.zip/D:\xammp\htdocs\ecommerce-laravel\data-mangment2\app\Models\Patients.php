<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Patients extends Model
{
    use HasFactory;
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($order) {
            $lastOrderNo = Patients::max('Order_No');
            $orderNumber = $lastOrderNo ? intval(substr($lastOrderNo, -6)) + 1 : 1;
            $order->Order_No = str_pad($orderNumber, 6, '0', STR_PAD_LEFT);
        });
    }
}
