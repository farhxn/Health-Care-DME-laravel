@section('title', 'Add Patient')
@include('layout.Head')
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="{{ url('/') }}">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( {{$pt}} )</span></li>
                        </a>
                        @foreach ($st as $sts)
                        @php
                        $cou = 0;
                        @endphp
                        @foreach ($drs as $pt)
                        @if ($sts->id == $pt->Order_Status)
                        @php
                        $cou++;
                        @endphp
                        @endif
                        @endforeach

                        <a class="nav-link bg-light" href="{{ url('StatusPatient',$sts->id) }}">
                            <li class="nav-item">{{ $sts->Status }} &nbsp; <span class="badge badge-light">
                                    (
                                    {{ $cou }}
                                    )
                                </span></li>
                        </a>
                        @endforeach
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserAdd') }}">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserList') }}">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientAdd') }}">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientList') }}">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentAdd') }}">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentList') }}">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusAdd') }}">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusList') }}">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorAdd') }}">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorList') }}">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Add Patient</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">


                    <div class="col">
                        <form method="post" action="{{ url('RegisterPatient') }}">
                            @csrf
                            <div class="card">
                                <h5 class="card-header">Add Patient Details</h5>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="col-form-label">Patient Name</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-bed"></i></span></span>
                                            <input type="text" required placeholder="Patient Name" name="name" class="form-control" value="{{ old('name') }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('name')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">Item</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-flask"></i></span></span>
                                            <input type="text" required placeholder="Item" value="{{ old('item') }}" class="form-control" name="item">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('item')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">Patient Date Of Birth</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-calculator"></i></span></span>
                                            <input type="date" required placeholder="Patient Date Of Birth" name="DOB" class="form-control" value="{{ old('DOB') }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('DOB')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">Patient Address</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-map"></i></span></span>
                                            <input type="text" required placeholder="Patient Address" name="address" class="form-control" value="{{ old('address') }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('address')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">Patient Insurance</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-info-circle"></i></span></span>
                                            <input type="text" required placeholder="Patient Insurance" name="insurance" class="form-control" value="{{ old('insurance') }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('insurance')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">Order No #</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa-solid fa-tag"></i></span></span>
                                            <input type="text" required placeholder="Order No#" name="orderNumber" class="form-control" value="{{ old('insurance') }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('orderNumber')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">Dr. Office Name</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-stethoscope"></i></span></span>
                                            <select class="form-control select2" required name="office_name">
                                                <option selected disabled>Dr. Office Name</option>
                                                @foreach ($dr as $drs)
                                                <option value="{{ $drs->id }}">{{ $drs->Office_Name }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('office_name')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-form-label">Order Status</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa-solid fa-square-poll-vertical"></i></span></span>
                                            <select class="form-control" id="status_id" required name="order_status">
                                                <option selected disabled>Order Status</option>
                                                @foreach ($st as $drs)
                                                <option value="{{ $drs->id }}">{{ $drs->Status }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('order_status')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>



                                    <div class="form-group" style="display: none;" id="resupplyDate-container">
                                        <label for="inputEmail3" class="col-sm-4 col-form-label">Resupply Date</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-calendar"></i></span></span>
                                            <input type="date" name="redate" class="form-control">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('redate')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>






                                    <div class="form-group">
                                        <label class="col-form-label">Assign Department</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa-solid fa-square-poll-vertical"></i></span></span>
                                            <select class="form-control" required name="department" id="dept-dropdown">
                                                <option selected disabled>Assign Department</option>
                                                @foreach ($dp as $dpItem)
                                                <option value="{{ $dpItem->id }}">{{ $dpItem->Department }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('department')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group" id="subdept-container" style="display: none;">
                                        <label class="col-form-label">Assign Sub Department</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa-solid fa-square-poll-vertical"></i></span></span>
                                            <select class="form-control form-control-sm" name="subdpt">
                                                <option value="Incontinence">Incontinence</option>
                                                <option  value="Wound Care">Wound Care</option>
                                                <option  value="Diabetic">Diabetic</option>
                                                <option  value="CGM">CGM</option>
                                            </select>
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('subdpt')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>




                                    <div class="form-group" id="user-container" style="display: none;">
                                        <label class="col-form-label">Assign User</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa-solid fa-user"></i></span></span>
                                            <select class="form-control" required name="user" id="user-dropdown">
                                                <option selected disabled>Assign User</option>
                                                @foreach ($dp as $dpItem)
                                                <option value="{{ $dpItem->id }}">{{ $dpItem->Department }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('user')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>


                                </div>
                                <div class="card-body border-top">
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group">
                                                <button type="submit" class="btn btn-block" style="background-color: #427ed1; color: white;">Submit</button>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>




            </div>
        </div>
    </div>

    @include('layout.footer')

    <script>
        $(document).ready(function() {
            $('.select2').select2({
                placeholder: "Select Dr. Office Name", // Optional placeholder text
                allowClear: true // Allows user to clear selected value
            });
        });
    </script>
