@section('title', 'Patient Detail')
@include('layout.Head')
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="{{ url('/') }}">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( {{$tp}} )</span></li>
                        </a>
                        @foreach ($st as $sts)
                        @php
                        $cou = 0;
                        @endphp
                        @foreach ($apt as $pta)
                        @if ($sts->id == $pta->Order_Status)
                        @php
                        $cou++;
                        @endphp
                        @endif
                        @endforeach

                        <a class="nav-link bg-light" href="{{ url('StatusPatient',$sts->id) }}">
                            <li class="nav-item">{{ $sts->Status }} &nbsp; <span class="badge badge-light">
                                    (
                                    {{ $cou }}
                                    )
                                </span></li>
                        </a>
                        @endforeach

                        @php
                        $user = Session::get('LoginRole');
                        @endphp
                        @if($user =="2")
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserAdd') }}">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserList') }}">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        @endif
                        @if($user =="1" || $user =="2")
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientAdd') }}">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientList') }}">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentAdd') }}">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentList') }}">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusAdd') }}">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusList') }}">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorAdd') }}">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorList') }}">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        @endif
                        @if($user =="2")
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        @endif
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Patient Detail</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">
                    <div class="offset col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="row">

                            <div class="col pl-lg-0 pl-md-0 border-left m-b-30">
                                <div class="product-details">
                                    <div class="border-bottom pb-3 mb-3">
                                        <h2 class="mb-3">{{ $pt->name }} Details </h2>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">


                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">PATIENT NAME</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->name }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">ITEM</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->Item }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">PATIENT DOB</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->Dob }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">PATIENT ADDRESS</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->Location }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">PATIENT INSURANCE</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->Insurance }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">ORDER #</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->Order_No }}</p>
                                                </div>
                                            </div>
                                            @php
                                            $offName = \App\Models\Doctors::find($pt->Off_Name);
                                            $statusName = \App\Models\Status::find($pt->Order_Status);
                                            @endphp
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">DR OFFICE</h4>
                                                    <p class="mb-0 ml-2">: {{ $offName->Office_Name }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">DR OFFICE PHONE NO</h4>
                                                    <p class="mb-0 ml-2">: {{ $offName->Phone_Num }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">DR OFFICE FAX NO</h4>
                                                    <p class="mb-0 ml-2">: {{ $offName->Fax }}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="row">
                                                <div class="col d-flex align-items-right">
                                                    <h4 class="mb-0">ORDER DATE</h4>
                                                    <p class="mb-0 ml-2">: {{ $pt->created_at }}</p>
                                                </div>
                                            </div>
                                            <br>
                                            <form style="border: 2px solid black; padding: 15px;" method="post" action="{{url('UpdatePatient',$pt->id)}}">
                                                @csrf
                                                <div class="row mb-3">
                                                    <label for="inputEmail3" class="col-sm-4 col-form-label">Status</label>
                                                    <div class="col-sm-8">
                                                        <div class="form-group">
                                                            <select id="status-dropdown" class="form-control form-control-sm" name="st">
                                                                @foreach ($st as $sts)
                                                                <option @if ( $sts->id == $pt->Order_Status)
                                                                    selected
                                                                    @endif value="{{ $sts->id }}">{{ $sts->Status }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                @php
                                                $statusName = \App\Models\Status::find($pt->Order_Status);
                                                @endphp
                                                <div class="row mb-3" id="resupplyDate-container" @if($statusName && !str_contains(strtolower($statusName->Status), 'resupply')) style="display: none;" @endif>
                                                    <label for="inputEmail3" class="col-sm-4 col-form-label">Resupply Date</label>
                                                    <div class="col-sm-8">
                                                        <div class="form-group">

                                                            <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-calendar"></i></span></span>
                                                                <input type="date" name="redate" class="form-control" @if($statusName && str_contains(strtolower($statusName->Status), 'resupply')) value="{{$pt->resupplyDate}}" @endif >
                                                            </div>
                                                            <span><small class="text-danger font-weight-light font-italic">
                                                                    @error('redate')
                                                                    {{ $message }}
                                                                    @enderror
                                                                </small></span>
                                                        </div>
                                                    </div>
                                                </div>



                                                <div class="row mb-3">
                                                    <label for="inputPassword3" class="col-sm-4 col-form-label">Department</label>
                                                    <div class="col-sm-8">
                                                        <div class="form-group">
                                                            <select class="form-control form-control-sm" id="statusdept-dropdown" name="dpt">
                                                                @foreach ($dp as $sts)
                                                                <option @if ( $sts->id == $pt->Dept)
                                                                    selected
                                                                    @endif value="{{ $sts->id }}">{{ $sts->Department }}</option>
                                                                @endforeach

                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>



                                                <div class="row mb-3" id="user-container" style="display: none;">
                                                    <label class="col-sm-4 col-form-label">Assign User</label>
                                                    <div class="col-sm-8">
                                                        <div class="form-group">
                                                            <div class="input-group mb-3">
                                                                <span class="input-group-prepend"><span class="input-group-text"><i class="fa-solid fa-user"></i></span></span>
                                                                <select class="form-control" name="user" id="user-dropdown">
                                                                    <option selected disabled>Assign User</option>

                                                                </select>
                                                            </div>
                                                            <span><small class="text-danger font-weight-light font-italic">
                                                                    @error('user')
                                                                    {{ $message }}
                                                                    @enderror
                                                                </small></span>
                                                        </div>
                                                    </div>
                                                </div>



                                                @php
                                                $dptName = \App\Models\Departments::find($pt->Dept);
                                                @endphp

                                                <div class="row mb-3" id="subdept-container" @if (!str_contains(strtolower($dptName->Department), 'resupply')) style="display: none;" @endif >
                                                    <label for="inputPassword3" class="col-sm-4 col-form-label">Sub Depart.</label>
                                                    <div class="col-sm-8">
                                                        <div class="form-group">
                                                            <select class="form-control form-control-sm" name="subdpt">
                                                                <option @if($pt->resupplyCat == "Incontinence") selected @endif value="Incontinence">Incontinence</option>
                                                                <option @if($pt->resupplyCat == "Wound Care") selected @endif value="Wound Care">Wound Care</option>
                                                                <option @if($pt->resupplyCat == "Diabetic") selected @endif value="Diabetic">Diabetic</option>
                                                                <option @if($pt->resupplyCat == "CGM") selected @endif value="CGM">CGM</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="product-size border-bottom">

                                    </div>
                                    <div class="product-description">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="row">
                                                    <div class="col">
                                                        <button data-toggle="modal" data-target="#AddNote" class="btn btn-primary btn-block p-2">Add
                                                            Notes</button>
                                                    </div>
                                                    <div class="col">
                                                        <button data-toggle="modal" data-target="#SeeNote" class="btn btn-primary btn-block p-2">See
                                                            All
                                                            Notes</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 m-b-60">
                                <div class="simple-card">
                                    <ul class="nav nav-tabs" id="myTab5" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active border-left-0" id="product-tab-1" data-toggle="tab" href="#tab-1" role="tab" aria-controls="product-tab-1" aria-selected="true">History</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent5">
                                        <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="product-tab-1">
                                            <ul class="list-unstyled arrow">
                                                @foreach ($act as $ac)
                                                <li>
                                                    {{ $ac->message }}
                                                    <br> <span><small class="text-dark font-weight-normal font-italic">
                                                            by {{ $ac->name }} at {{ $ac->created_at }}
                                                        </small></span>
                                                </li>
                                                @endforeach

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    @include('layout.footer')

    <div class="modal fade" id="AddNote" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Notes</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="{{url('AddNote',$pt->id)}}">
                        @csrf
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Add Note:</label>
                            <textarea class="form-control" name="note" required id="message-text"></textarea>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Send message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="SeeNote" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">See All Notes</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="tab-content" id="myTabContent5">
                        <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="product-tab-1">
                            <ul class="list-unstyled arrow">
                                @foreach ($not as $no)
                                <li>
                                    {{ $no->note }}
                                    <br> <span><small class="text-dark font-weight-normal font-italic">
                                            by {{ $no->name }} at {{ $no->created_at }}
                                        </small></span>
                                </li>
                                @endforeach

                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                </div>
            </div>
        </div>
    </div>
    @if (Session::has('fail'))
<script>
    Swal.fire({
        title: "Error",
        text: "No User Found in that department",
        icon: "Error"
    });
</script>
@endif
