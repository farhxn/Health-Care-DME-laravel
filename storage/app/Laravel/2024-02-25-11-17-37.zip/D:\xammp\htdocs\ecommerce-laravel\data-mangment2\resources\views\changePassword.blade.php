@section('title', 'Change Password')
@include('layout.Head')
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="{{ url('/') }}">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( {{$pt}} )</span></li>
                        </a>
                        @foreach ($st as $sts)
                        @php
                        $cou = 0;
                        @endphp
                        @foreach ($drs as $pt)
                        @if ($sts->id == $pt->Order_Status)
                        @php
                        $cou++;
                        @endphp
                        @endif
                        @endforeach

                        <a class="nav-link bg-light" href="{{ url('StatusPatient',$sts->id) }}">
                            <li class="nav-item">{{ $sts->Status }} &nbsp; <span class="badge badge-light">
                                    (
                                    {{ $cou }}
                                    )
                                </span></li>
                        </a>
                        @endforeach

                        @php
                        $user = Session::get('LoginRole');
                        @endphp
                        @if($user =="2")
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserAdd') }}">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserList') }}">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        @endif
                        @if($user =="1" || $user =="2")
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientAdd') }}">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientList') }}">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentAdd') }}">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentList') }}">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusAdd') }}">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusList') }}">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorAdd') }}">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorList') }}">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        @endif
                        @if($user =="2")
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        @endif
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <br><br>
                </div>
            </div>

            <div class="ecommerce-widget">
                <div class="row offset-2">
                    <div class="col-8">
                        <div class="card">
                            <h5></h5>
                            <div class="card ">
                                <div class="card-header text-center"><a href='/'><img class="logo-img" src="assets/images/logo.png" height="65" width="250" alt="logo"></a><span class="splash-description">Enter New Password.</span></div>
                                <div class="card-body">
                                    <form method="post" action="{{url('UpdateChangePassword')}}">
                                        @csrf
                                        <div class="form-group">
                                            <input class="form-control form-control-lg" id="E-Mail" type="mail" name="password" required placeholder="New Password" autocomplete="off">
                                            <span><small class="text-danger font-weight-light font-italic">@error('password'){{ $message }} @enderror</small></span>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-lg btn-block">Change Password</button>
                                    </form>
                                </div>
                                <div class="card-footer bg-white p-0">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    @include('layout.footer')
