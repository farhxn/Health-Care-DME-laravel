@section('title', 'Edit Patient')
@include('layout.Head')
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="{{ url('/') }}">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( {{$pt}} )</span></li>
                        </a>
                        @foreach ($st as $sts)
                        @php
                        $cou = 0;
                        @endphp
                        @foreach ($drs as $pt)
                        @if ($sts->id == $pt->Order_Status)
                        @php
                        $cou++;
                        @endphp
                        @endif
                        @endforeach

                        <a class="nav-link bg-light" href="{{ url('StatusPatient',$sts->id) }}">
                            <li class="nav-item">{{ $sts->Status }} &nbsp; <span class="badge badge-light">
                                    (
                                    {{ $cou }}
                                    )
                                </span></li>
                        </a>
                        @endforeach
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserAdd') }}">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserList') }}">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientAdd') }}">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientList') }}">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentAdd') }}">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentList') }}">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusAdd') }}">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusList') }}">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorAdd') }}">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorList') }}">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Edit {{ $user->name }}'s Detail</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">


                    <div class="col">
                        <form method="post" action="{{ url('EditUser', $user->id) }}">
                            @csrf
                            <div class="card">
                                <h5 class="card-header">Edit {{ $user->name }}'s Detail</h5>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="col-form-label">User Name</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-user"></i></span></span>
                                            <input type="text" required placeholder="User Name" name="name" class="form-control" value="{{ $user->name }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('name')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">User Mail</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-envelope"></i></span></span>
                                            <input type="mail" required placeholder="User Email" name="mail" class="form-control" value="{{ $user->email }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('mail')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-form-label">User Role</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-user-secret"></i></span></span>
                                            <select class="form-control" required name="role" id="role-dropdown">
                                                <option disabled>Select User Role</option>
                                                <option value="0" @if ($user->role === '0') selected @endif>User</option>
                                                <option value="1" @if ($user->role === '1') selected @endif>Manager</option>
                                                <option value="2" @if ($user->role === '2') selected @endif>Admin</option>
                                            </select>

                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('role')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group" id="max-order-container" style="display: none;">
                                        <label class="col-form-label">User Max Pending Order</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-cart-flatbed"></i></span></span>
                                            <input type="number"  placeholder="User Max Pending Order" name="max_order" class="form-control" value="{{ $user->max_pending_order }}">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('max_order')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>

                                    <div class="form-group" id="Dept-container" style="display: none; width: 100%;">
                                        <label class="col-form-label">User Department</label>
                                        <div class="input-group mb-3">
                                            <span class="input-group-prepend">
                                                <span class="input-group-text"><i class="fa-solid fa-building-user"></i></span>
                                            </span>
                                            <select class="form-control select2" name="dept[]" multiple="multiple">
                                                <option disabled>Select User Department</option>
                                                @php
                                                // Decode the Dept JSON string into a PHP array, ensuring it's always an array
                                                $selectedDepts = json_decode($user->Dept, true);
                                                // If $selectedDepts is not an array, set it to an empty array
                                                if (!is_array($selectedDepts)) {
                                                $selectedDepts = [];
                                                }
                                                @endphp
                                                @foreach ($dep as $dept)
                                                <option value="{{ $dept->id }}" {{ in_array($dept->id, $selectedDepts) ? 'selected' : '' }}>
                                                    {{ $dept->Department }}
                                                </option>
                                                @endforeach
                                            </select>

                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                @error('dept')
                                                {{ $message }}
                                                @enderror
                                            </small></span>
                                    </div>


                                </div>
                                <div class="card-body border-top">
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group">
                                                <button type="submit" class="btn btn-block" style="background-color: #427ed1; color: white;">Submit</button>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('layout.footer')