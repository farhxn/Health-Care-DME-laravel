<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Report</title>
    <style>
        body { font-family: sans-serif; }
        .container { width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto; }
        .row { display: flex; flex-wrap: wrap; margin-right: -15px; margin-left: -15px; }
        .col-md-12 { flex: 0 0 100%; max-width: 100%; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
        h2 { margin-top: 20px; }
    </style>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Patient Report</h2>
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>PT Name</th>
                        <th>Item</th>
                        <th>Dr. OFF.</th>
                        <th>DOB</th>
                        <th>LOCATION</th>
                        <th>INSURANCE</th>
                        <th>Status</th>
                        <th>Order Date</th>
                    </tr>
                </thead>
                <tbody>
                        <?php
                        $sno = 1;
                        ?>
                        @foreach ($drs as $pt)
                        @php
                        $offName = \App\Models\Doctors::find($pt->Off_Name);
                        $statusName = \App\Models\Status::find($pt->Order_Status);
                        @endphp

                        <tr onclick="window.location='/PatientDetail/{{ $pt->id }}';">
                            <td>{{ $sno++ }}</td>
                            <td>{{ $pt->name }}</td>
                            <td>{{ $pt->Item }}</td>

                            <td>{{ $offName->Office_Name }}</td>
                            <td>{{ $pt->Dob }}</td>
                            <td>{{ $pt->Location }}</td>
                            <td>{{ $pt->Insurance }}</td>
                            <td>{{ $statusName->Status }}
                            </td>
                            <td>{{ $pt->created_at }}</td>

                        </tr>
                        @endforeach
                    </tbody>

            </table>
        </div>
    </div>
</div>

</body>
</html>
