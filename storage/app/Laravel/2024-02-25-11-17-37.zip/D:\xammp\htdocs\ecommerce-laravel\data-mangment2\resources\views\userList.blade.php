@section('title', 'Users List')
@include('layout.Head')
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="{{ url('/') }}">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( {{$pt}} )</span></li>
                        </a>
                        @foreach ($st as $sts)
                        @php
                        $cou = 0;
                        @endphp
                        @foreach ($drs as $pt)
                        @if ($sts->id == $pt->Order_Status)
                        @php
                        $cou++;
                        @endphp
                        @endif
                        @endforeach

                        <a class="nav-link bg-light" href="{{ url('StatusPatient',$sts->id) }}">
                            <li class="nav-item">{{ $sts->Status }} &nbsp; <span class="badge badge-light">
                                    (
                                    {{ $cou }}
                                    )
                                </span></li>
                        </a>
                        @endforeach
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserAdd') }}">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('UserList') }}">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientAdd') }}">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('PatientList') }}">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentAdd') }}">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DepartmentList') }}">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusAdd') }}">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('StatusList') }}">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorAdd') }}">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url('DoctorList') }}">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Users List</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">

                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">
                    <div class="col">
                        <div class="card">
                            <h5></h5>
                            <div class="container card-header">

                            </div>
                            <br>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table display" id="myTable">
                                        <thead class="bg-light">
                                            <tr class="border-0">
                                                <th class="border-0">No.</th>
                                                <th class="border-0">Name</th>
                                                <th class="border-0">E-Mail</th>
                                                <th class="border-0">Role</th>
                                                <th class="border-0">Department</th>
                                            
                                                <th class="border-0">Status</th>
                                                <th class="border-0">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sno = 1;
                                            ?>
                                            @foreach ($users as $user)
                                            <tr onclick="window.location='{{ url('userDetail', $user->id) }}';">
                                                <td>{{ $sno++ }}</td>
                                                <td>{{ $user->name }}</td>
                                                <td>{{ $user->email }}</td>
                                                <td>
                                                    @if ($user->role == '2')
                                                    Admin
                                                    @elseif($user->role == '1')
                                                    Manager
                                                    @else
                                                    User
                                                    @endif
                                                </td>

                                                <td>
                                                    @if($user->Dept)
                                                    @php
                                                    $deptIds = json_decode($user->Dept, true);
                                                    @endphp

                                                    @if(is_array($deptIds) && !empty($deptIds))
                                                    <ol>
                                                        @foreach ($deptIds as $deptId)
                                                        @php
                                                        $department = \App\Models\Departments::find($deptId);
                                                        @endphp

                                                        <li>{{ $department ? $department->Department : 'Department not found' }}</li>
                                                        @endforeach
                                                    </ol>
                                                    @endif
                                                    @endif

                                                </td>
                                                <td>
                                                    @if ($user->status == '1')
                                                    <span class="badge-dot badge-danger mr-1"></span>Close
                                                    @else
                                                    <span class="badge-dot badge-success mr-1"></span>Open
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="{{ url('Useredit', $user->id) }}" class="btn btn-sm btn-warning" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit {{ $user->name }}'s details"><i class="fa fa-pen-to-square"></i></a>
                                                    <button data-url="{{ url('DeleteUser', $user->id) }}" class="btn btn-sm btn-danger delete-btn" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete {{ $user->name }}'s account"><i class="fa fa-trash"></i></button>
                                                    <button data-url="{{ url('BanUser', $user->id) }}" class="btn btn-sm btn-primary ban-btn" data-toggle="tooltip" data-placement="top" title="" data-original-title="Ban {{ $user->name }}'s account"><i class="fa fa-ban"></i></a>
                                                </td>
                                            </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    @include('layout.footer')
