<?php

use App\Http\Controllers\MainController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[MainController::class,'index'])->middleware('isloggedin');
Route::post('/log', [MainController::class, 'store']);

Route::get('/FilterPatient',[MainController::class,'FilterPatient']);
Route::get('/FilterPatient2',[MainController::class,'FilterPatient2']);
Route::get('/DepartPatient/{id}',[MainController::class,'DepartPatient']);
Route::get('/StatusPatient/{id}',[MainController::class,'StatusPatient']);
Route::get('/ResupplyPatient/{id}',[MainController::class,'ResupplyPatient']);
Route::get('/followUpPatient/{id}',[MainController::class,'followUpPatient']);
Route::get('/subDept/{id}',[MainController::class,'subDept']);
Route::get('/PatientReport',[MainController::class,'PatientReport']);

//Patient Route
Route::get('/PatientAdd',[MainController::class,'AddPatient']);
Route::get('/DepartmentUser/{id}',[MainController::class,'DepartmentUser']);
Route::get('/PatientList',[MainController::class,'PatientList']);
Route::get('/EditPatient/{id}',[MainController::class,'editPatient']);
Route::get('/PatientDetail/{id}',[MainController::class,'PatientDetail']);
Route::post('/EditPatientDetail/{id}',[MainController::class,'EditPatientDetail']);
Route::post('/UpdatePatient/{id}',[MainController::class,'UpdatePatient']);
Route::post('/DeletePatient/{id}',[MainController::class,'DeletePatient']);
Route::post('/RegisterPatient',[MainController::class,'RegisterPatient']);
Route::post('/AddNote/{id}',[MainController::class,'AddNote']);


//Department Route
Route::get('/DepartmentAdd',[MainController::class,'AddDepart']);
Route::get('/DepartmentList',[MainController::class,'DepartList']);
Route::get('/EditDepartment/{id}',[MainController::class,'editDepart']);
Route::post('/EditDepartmentDetail/{id}',[MainController::class,'EditDepartDetail']);
Route::post('/DeleteDepartment/{id}',[MainController::class,'DeleteDepart']);
Route::post('/RegisterDepartment',[MainController::class,'RegisterDepart']);


//Status Route
Route::get('/StatusAdd',[MainController::class,'AddStatus']);
Route::get('/StatusList',[MainController::class,'StatusList']);
Route::get('/EditStatus/{id}',[MainController::class,'editStatus']);
Route::post('/EditStatusDetail/{id}',[MainController::class,'EditStatusDetail']);
Route::post('/DeleteStatus/{id}',[MainController::class,'DeleteStatus']);
Route::post('/RegisterStatus',[MainController::class,'RegisterStatus']);

//Doctor Route
Route::get('/DoctorAdd',[MainController::class,'AddDoctor']);
Route::get('/DoctorList',[MainController::class,'DoctorList']);
Route::get('/EditDoctor/{id}',[MainController::class,'EditDoctor']);
Route::post('/EditDoctorDetail/{id}',[MainController::class,'EditDoctorDetail']);
Route::post('/DeleteDoctor/{id}',[MainController::class,'DeleteDoctor']);
Route::post('/RegisterDoctor',[MainController::class,'RegisterDoctor']);

//Login Route
Route::post('/LoginUser',[MainController::class,'LoginUser']);
Route::post('/UpdatePassword',[MainController::class,'UpdatePassword']);
Route::post('/UpdateChangePassword',[MainController::class,'UpdateChangePassword']);
Route::post('/VerifyOTP',[MainController::class,'VerifyOTP']);
Route::get('/AuthMail',[MainController::class,'AuthenticationMail']);
Route::get('/Login',[MainController::class,'login']);
Route::get('/OTPVerify',[MainController::class,'OTPVerify']);
Route::get('/forgetPassword',[MainController::class,'forgetPassword']);
Route::get('/ChangePassword',[MainController::class,'ChangePassword']);
Route::get('/logout',[MainController::class,'logout']);


//User Route
Route::post('/RegisterUser',[MainController::class,'RegisterUser']);
Route::post('/EditUser/{id}',[MainController::class,'EditUserDetail']);
Route::post('/DeleteUser/{id}',[MainController::class,'DeleteUser']);
Route::post('/BanUser/{id}',[MainController::class,'BanUser']);
Route::get('/UserAdd',[MainController::class,'AddUser']);
Route::get('/UserList',[MainController::class,'UserList']);
Route::get('/Useredit/{id}',[MainController::class,'EditUser']);
Route::get('/userDetail/{id}',[MainController::class,'userDetail']);
