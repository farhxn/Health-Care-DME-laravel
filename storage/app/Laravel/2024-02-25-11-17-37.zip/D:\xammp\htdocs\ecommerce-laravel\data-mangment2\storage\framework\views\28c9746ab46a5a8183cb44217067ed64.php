<?php $__env->startSection('title', 'Patient List'); ?>
<?php echo $__env->make('layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( <?php echo e($pt); ?> )</span></li>
                        </a>
                        <?php $__currentLoopData = $st; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $cou = 0;
                        ?>
                        <?php $__currentLoopData = $drs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sts->id == $pt->Order_Status): ?>
                        <?php
                        $cou++;
                        ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a class="nav-link bg-light" href="<?php echo e(url('StatusPatient',$sts->id)); ?>">
                            <li class="nav-item"><?php echo e($sts->Status); ?> &nbsp; <span class="badge badge-light">
                                    (
                                    <?php echo e($cou); ?>

                                    )
                                </span></li>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('UserAdd')); ?>">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('UserList')); ?>">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientAdd')); ?>">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientList')); ?>">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DepartmentAdd')); ?>">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DepartmentList')); ?>">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('StatusAdd')); ?>">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('StatusList')); ?>">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DoctorAdd')); ?>">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DoctorList')); ?>">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Patient List</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">
                    <?php $__currentLoopData = $dp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3 p-2">
                            <a href="<?php echo e(url('DepartPatient',$dps->id)); ?>" class="btn btn-block"
                                style="background-color: #427ed1; color: white;"><?php echo e($dps->Department); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br><br>


                <div class="row">
                    <div class="col">
                        <div class="card">
                            <h5></h5>
                            <div class="container card-header">
                                <form class="form-inline mr-auto" action="<?php echo e(url('/FilterPatient')); ?>"
                                    method="get">

                                    <div class="row">
                                        <div class="form-group mb-2">
                                            <label>&nbsp;<strong>FILTERS </strong>&nbsp;</label>
                                            <div class="form-group">
                                                <select class="form-control" name="date">
                                                    <option selected disabled>Dates</option>
                                                    <option value="4">Today</option>
                                                    <option value="1">Yesterday</option>
                                                    <option value="2">Week</option>
                                                    <option value="3">Month</option>
                                                </select>
                                            </div>
                                        </div>
                                        <br>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </small></span>

                                        &nbsp;&nbsp;&nbsp;
                                        <div class="form-group mb-2">
                                            <label>&nbsp;<strong> Categories</strong> &nbsp;</label>
                                            <div class="form-group">
                                                <select class="form-control " name="status">
                                                    <option selected disabled>Status</option>
                                                    <?php $__currentLoopData = $st; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($sts->id); ?>"><?php echo e($sts->Status); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <span><small class="text-danger font-weight-light font-italic">
                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </small></span>
                                        </div>&nbsp;&nbsp;&nbsp;
                                        <div class="col2">
                                            <button type="submit" class="btn btn-block btn-sm p-2"
                                                style="background-color: #427ed1; color: white;">Apply Filter</button>
                                        </div>
                                    </div>
                                </form>
                                <br>
                            </div>
                            <br>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table display" id="myTable">
                                        <thead class="bg-light">
                                            <tr class="border-0">
                                                <th class="border-0">No.</th>
                                                <th class="border-0">PT Name</th>
                                                <th class="border-0">Item</th>
                                                <th class="border-0">Dr. OFF.</th>
                                                <th class="border-0">DOB</th>
                                                <th class="border-0">LOCATION</th>
                                                <th class="border-0">INSURANCE</th>
                                                <th class="border-0">Status</th>
                                                <th class="border-0">Order Date</th>
                                                <th class="border-0">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sno = 1;
                                            ?>
                                            <?php $__currentLoopData = $drs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $offName = \App\Models\Doctors::find($pt->Off_Name);
                                                    $statusName = \App\Models\Status::find($pt->Order_Status);
                                                ?>

                                                <tr onclick="window.location='/PatientDetail/<?php echo e($pt->id); ?>';">
                                                    <td><?php echo e($sno++); ?></td>
                                                    <td><?php echo e($pt->name); ?></td>
                                                    <td><?php echo e($pt->Item); ?></td>

                                                    <td><?php echo e($offName->Office_Name); ?></td>
                                                    <td><?php echo e($pt->Dob); ?></td>
                                                    <td><?php echo e($pt->Location); ?></td>
                                                    <td><?php echo e($pt->Insurance); ?></td>
                                                    <td><?php echo e($statusName->Status); ?>

                                                    </td>
                                                    <td><?php echo e($pt->created_at); ?></td>
                                                    <td class="text-center">
                                                        <a href="<?php echo e(url('EditPatient', $pt->id)); ?>"
                                                            class="btn btn-sm btn-warning" data-toggle="tooltip"
                                                            data-placement="top" title=""
                                                            data-original-title="Edit <?php echo e($pt->name); ?>'s Details"><i
                                                                class="fa fa-pen-to-square"></i></a>
                                                        <button data-url="<?php echo e(url('DeletePatient', $pt->id)); ?>"
                                                            class="btn btn-sm btn-danger delete-btn"
                                                            data-toggle="tooltip" data-placement="top" title=""
                                                            data-original-title="Delete <?php echo e($pt->name); ?> "><i
                                                                class="fa fa-trash"></i></button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xammp\htdocs\ecommerce-laravel\data-mangment2\resources\views/PatientList.blade.php ENDPATH**/ ?>