<?php $__env->startSection('title','Home'); ?>
<?php echo $__env->make('layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link  active" href="index.html">
                            <li class="nav-item">Status 1 &nbsp; <span class="badge badge-light">( 3 )</span></li>
                        </a>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item">Status 2 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                        </a>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item">Status 3 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                        </a>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item">Status 4 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                        </a>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientAdd')); ?>">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">INTAKE DEPARTMENT</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 1</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 2</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block " style="background-color: #427ed1; color: white;">Department 3</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block " style="background-color: #427ed1; color: white;">Department 4</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 5</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 6</a>
                    </div>
                </div>

                <div class="row">
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block " style="background-color: #427ed1; color: white;">Department 1</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block " style="background-color: #427ed1; color: white;">Department 2</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block " style="background-color: #427ed1; color: white;">Department 3</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 4</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 5</a>
                    </div>
                    <div class="col p-2">
                        <a href="departments.html" class="btn btn-block" style="background-color: #427ed1; color: white;">Department 6</a>
                    </div>
                </div> <br><br>


                <div class="row">
                    <div class="col">
                        <div class="card">
                            <h5></h5>
                            <div class="container card-header">
                                <form class="form-inline mr-auto">
                                    <div class="row">
                                        <div class="form-group mb-2">
                                            <label>&nbsp;<strong>FILTERS </strong>&nbsp;</label>
                                            <div class="form-group">
                                                <select class="form-control ">
                                                    <option selected disabled>All Dates</option>
                                                </select>
                                            </div>
                                        </div>

                                        &nbsp;&nbsp;&nbsp;
                                        <div class="form-group mb-2">
                                            <label>&nbsp;<strong> Categories</strong> &nbsp;</label>
                                            <div class="form-group">
                                                <select class="form-control ">
                                                    <option selected disabled>Pending</option>
                                                    <option>Pending1</option>
                                                    <option>Pending2</option>
                                                    <option>Pending3</option>
                                                </select>
                                            </div>
                                        </div>&nbsp;&nbsp;&nbsp;
                                        <div class="col2">

                                            <button type="submit" class="btn btn-block btn-sm p-2" style="background-color: #427ed1; color: white;">Apply Filter</button>
                                        </div>
                                    </div>
                                </form>
                                <br>
                            </div>
                            <br>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table display" id="myTable">
                                        <thead class="bg-light">
                                            <tr class="border-0">
                                                <th class="border-0">No.</th>
                                                <th class="border-0">PT Name</th>
                                                <th class="border-0">Item</th>
                                                <th class="border-0">DR OFFICE NAME</th>
                                                <th class="border-0">DOB</th>
                                                <th class="border-0">LOCATION</th>
                                                <th class="border-0">INSURANCE</th>
                                                <th class="border-0">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr onclick="window.location='bill.html';">
                                                <td>1</td>
                                                <td>DOROTHY MORTON</td>
                                                <td>KNEE BRACE</td>
                                                <td>HEALTHCARE DME</td>
                                                <td>02-29-1993</td>
                                                <td>ANN ARBOR</td>
                                                <td>MEDICARE</td>
                                                <td>
                                                    <span class="badge-dot badge-brand mr-1"></span>Pending
                                                </td>
                                            </tr>
                                            <tr onclick="window.location='bill.html';">
                                                <td>2</td>
                                                <td>DOROTHY MORTON</td>
                                                <td>KNEE BRACE</td>
                                                <td>HEALTHCARE DME</td>
                                                <td>02-29-1993</td>
                                                <td>ANN ARBOR</td>
                                                <td>MEDICARE</td>
                                                <td>
                                                    <span class="badge-dot badge-brand mr-1"></span>Pending
                                                </td>
                                            </tr>
                                            <tr onclick="window.location='bill.html';">
                                                <td>3</td>
                                                <td>DOROTHY MORTON</td>
                                                <td>KNEE BRACE</td>
                                                <td>HEALTHCARE DME</td>
                                                <td>02-29-1993</td>
                                                <td>ANN ARBOR</td>
                                                <td>MEDICARE</td>
                                                <td>
                                                    <span class="badge-dot badge-brand mr-1"></span>Pending
                                                </td>
                                            </tr>
                                            <tr onclick="window.location='bill.html';">
                                                <td>4</td>
                                                <td>DOROTHY MORTON</td>
                                                <td>KNEE BRACE</td>
                                                <td>HEALTHCARE DME</td>
                                                <td>02-29-1993</td>
                                                <td>ANN ARBOR</td>
                                                <td>MEDICARE</td>
                                                <td>
                                                    <span class="badge-dot badge-brand mr-1"></span>Pending
                                                </td>
                                            </tr>
                                            <tr onclick="window.location='bill.html';">
                                                <td>5</td>
                                                <td>DOROTHY MORTON</td>
                                                <td>KNEE BRACE</td>
                                                <td>HEALTHCARE DME</td>
                                                <td>02-29-1993</td>
                                                <td>ANN ARBOR</td>
                                                <td>MEDICARE</td>
                                                <td>
                                                    <span class="badge-dot badge-brand mr-1"></span>Pending
                                                </td>
                                            </tr>
                                            <tr onclick="window.location='bill.html';">
                                                <td>6</td>
                                                <td>DOROTHY MORTON</td>
                                                <td>KNEE BRACE</td>
                                                <td>HEALTHCARE DME</td>
                                                <td>02-29-1993</td>
                                                <td>ANN ARBOR</td>
                                                <td>MEDICARE</td>
                                                <td>
                                                    <span class="badge-dot badge-brand mr-1"></span>Pending
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\data-mangment\resources\views/index.blade.php ENDPATH**/ ?>