<?php echo e($slot); ?>

<?php /**PATH D:\xammp\htdocs\ecommerce-laravel\data-mangment2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>