<?php $__env->startSection('title', 'Users Detail'); ?>
<?php echo $__env->make('layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( <?php echo e($pt); ?> )</span></li>
                        </a>
                        <?php $__currentLoopData = $st; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $cou = 0;
                        ?>
                        <?php $__currentLoopData = $dr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sts->id == $pt->Order_Status): ?>
                        <?php
                        $cou++;
                        ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a class="nav-link bg-light" href="<?php echo e(url('StatusPatient',$sts->id)); ?>">
                            <li class="nav-item"><?php echo e($sts->Status); ?> &nbsp; <span class="badge badge-light">
                                    (
                                    <?php echo e($cou); ?>

                                    )
                                </span></li>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('UserAdd')); ?>">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('UserList')); ?>">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientAdd')); ?>">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientList')); ?>">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DepartmentAdd')); ?>">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DepartmentList')); ?>">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('StatusAdd')); ?>">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('StatusList')); ?>">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DoctorAdd')); ?>">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DoctorList')); ?>">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto"><?php echo e($user->name); ?>'s Detail</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">
                    <div class="offset col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="row">

                            <div class="col pl-lg-0 pl-md-0 border-left m-b-30">
                                <div class="product-details">
                                    <div class="border-bottom pb-3 mb-3">
                                        <h2 class="mb-3">User Details </h2>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">


                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">NAME</h4>
                                                    <p class="mb-0 ml-2">: <?php echo e($user->name); ?></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">E-Mail</h4>
                                                    <p class="mb-0 ml-2">: <?php echo e($user->email); ?></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">Role</h4>
                                                    <p class="mb-0 ml-2">:
                                                        <?php if($user->role == '2'): ?>
                                                            Admin
                                                        <?php elseif($user->role == '1'): ?>
                                                            Manager
                                                        <?php else: ?>
                                                            User
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-center">
                                                    <h4 class="mb-0">Status</h4>
                                                    <p class="mb-0 ml-2">: <?php if($user->status == '1'): ?>
                                                            <span class="badge-dot badge-danger mr-1"></span>Close
                                                        <?php else: ?>
                                                            <span class="badge-dot badge-success mr-1"></span>Open
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-6">
                                            <div class="row">
                                                <div class="col d-flex align-items-right">
                                                    <h4 class="mb-0">Today Orders</h4>
                                                    <p class="mb-0 ml-2">: <?php echo e($tdpCount); ?></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col d-flex align-items-right">
                                                    <h4 class="mb-0">Total Orders</h4>
                                                    <p class="mb-0 ml-2">: <?php echo e($tpCount); ?></p>
                                                </div>
                                            </div>



                                        </div>
                                    </div>
                                    <div class="product-size border-bottom">
                                    </div>
                                </div>
                            </div>


                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 m-b-60">
                                <div class="simple-card">
                                    <ul class="nav nav-tabs" id="myTab5" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active border-left-0" id="product-tab-1"
                                                data-toggle="tab" href="#tab-1" role="tab"
                                                aria-controls="product-tab-1" aria-selected="true">All Orders</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent5">
                                        <div class="tab-pane fade show active" id="tab-1" role="tabpanel"
                                            aria-labelledby="product-tab-1">
                                            <div class="table-responsive">
                                            <table class="table display" id="myTable">
                                        <thead class="bg-light">
                                            <tr class="border-0">
                                                <th class="border-0">No.</th>
                                                <th class="border-0">PT Name</th>
                                                <th class="border-0">Item</th>
                                                <th class="border-0">Dr. OFF.</th>
                                                <th class="border-0">DOB</th>
                                                <th class="border-0">LOCATION</th>
                                                <th class="border-0">INSURANCE</th>
                                                <th class="border-0">Status</th>
                                                <th class="border-0">Order Date</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sno = 1;
                                            ?>
                                            <?php $__currentLoopData = $drs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $offName = \App\Models\Doctors::find($pt->Off_Name);
                                                    $statusName = \App\Models\Status::find($pt->Order_Status);
                                                ?>

                                                <tr onclick="window.location='/PatientDetail/<?php echo e($pt->id); ?>';">
                                                    <td><?php echo e($sno++); ?></td>
                                                    <td><?php echo e($pt->name); ?></td>
                                                    <td><?php echo e($pt->Item); ?></td>

                                                    <td><?php echo e($offName->Office_Name); ?></td>
                                                    <td><?php echo e($pt->Dob); ?></td>
                                                    <td><?php echo e($pt->Location); ?></td>
                                                    <td><?php echo e($pt->Insurance); ?></td>
                                                    <td><?php echo e($statusName->Status); ?>

                                                    </td>
                                                    <td><?php echo e($pt->created_at); ?></td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xammp\htdocs\ecommerce-laravel\data-mangment2\resources\views/userDetail.blade.php ENDPATH**/ ?>