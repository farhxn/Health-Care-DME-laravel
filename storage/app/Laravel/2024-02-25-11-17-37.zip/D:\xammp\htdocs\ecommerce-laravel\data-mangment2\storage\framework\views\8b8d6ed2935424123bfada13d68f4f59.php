<?php $__env->startSection('title', 'Edit Status'); ?>
<?php echo $__env->make('layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>">
                            <li class="nav-item">All &nbsp; <span class="badge badge-light">( <?php echo e($pt); ?> )</span></li>
                        </a>
                        <?php $__currentLoopData = $s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $cou = 0;
                        ?>
                        <?php $__currentLoopData = $drs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sts->id == $pt->Order_Status): ?>
                        <?php
                        $cou++;
                        ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a class="nav-link bg-light" href="<?php echo e(url('StatusPatient',$sts->id)); ?>">
                            <li class="nav-item"><?php echo e($sts->Status); ?> &nbsp; <span class="badge badge-light">
                                    (
                                    <?php echo e($cou); ?>

                                    )
                                </span></li>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('UserAdd')); ?>">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('UserList')); ?>">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage
                                Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientAdd')); ?>">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('PatientList')); ?>">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage
                                Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DepartmentAdd')); ?>">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DepartmentList')); ?>">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('StatusAdd')); ?>">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('StatusList')); ?>">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DoctorAdd')); ?>">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(url('DoctorList')); ?>">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="#">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                        <br> <br> <br> <br> <br>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Edit <?php echo e($st->Status); ?></h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">


                    <div class="col">
                        <form method="post" action="<?php echo e(url('EditStatusDetail',$st->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <h5 class="card-header">Edit <?php echo e($st->Status); ?> Details</h5>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="col-form-label">Status</label>
                                        <div class="input-group mb-3"><span class="input-group-prepend"><span
                                                    class="input-group-text"><i class="fa-solid fa-square-poll-vertical"></i></span></span>
                                            <input type="text" required placeholder="Status" name="status"
                                                class="form-control" value="<?php echo e($st->Status); ?>">
                                        </div>
                                        <span><small class="text-danger font-weight-light font-italic">
                                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </small></span>
                                    </div>

                                </div>

                                <div class="card-body border-top">
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group">
                                                <button type="submit" class="btn btn-block"
                                                    style="background-color: #427ed1; color: white;">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\xammp\htdocs\ecommerce-laravel\data-mangment2\resources\views/editStatus.blade.php ENDPATH**/ ?>