<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                Created by <a target="_blank" href="farhanatif.netlify.app">M.Farhan Atif</a> with <i class="fa fa-heart"></i>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <!-- <a href="javascript: void(0);">About</a>
                <a href="javascript: void(0);">Support</a>
                <a href="javascript: void(0);">Contact Us</a> -->
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<script src="
https://cdn.jsdelivr.net/npm/sweetalert2@11.10.5/dist/sweetalert2.all.min.js
"></script>
<script src="https://colorlib.com//polygon/concept/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<script src="https://colorlib.com//polygon/concept/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="https://colorlib.com//polygon/concept/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<script src="https://colorlib.com//polygon/concept/assets/libs/js/main-js.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
</body>

</html>
<?php if(Session::has('success')): ?>
<script>
    Swal.fire({
        title: "Success",
        text: "Saved Successfully",
        icon: "success"
    });
</script>
<?php endif; ?>
<?php if(Session::has('fail')): ?>
<script>
    Swal.fire({
        title: "Error",
        text: "Invalid Credentials",
        icon: "Error"
    });
</script>
<?php endif; ?>
<?php if(Session::has('Ban')): ?>
<script>
    Swal.fire({
        title: "Error",
        text: "Your Account is suspended!!!!",
        icon: "Error"
    });
</script>
<?php endif; ?>



<script>
    $(document).ready(function() {
        //Data Tabke
        $('#myTable').DataTable();

        //User Table fiekds
        function toggleMaxOrderField() {
            var selectedRole = $('#role-dropdown').val();
            if (selectedRole === '0') {
                $('#max-order-container').show();
                $('#Dept-container').show();

                //Multi Selects
                $('.select2').select2({
                    placeholder: "Select User Department", // Optional placeholder text
                    allowClear: true // Allows user to clear selected value
                });


            } else {
                $('#max-order-container').hide();
                $('#Dept-container').hide();
                // $('.select2').select2('destroy').select2({});
            }

            $('#dept-dropdown').change(function() {
                var selectedDeptText = $("#dept-dropdown option:selected").text().toLowerCase(); // Get the text and convert to lowercase
                if (selectedDeptText.includes("resupply")) { // Check if the text includes 'resupply'
                    $('#subdept-container').show();
                } else {
                    $('#subdept-container').hide();
                }
                var selectedDept = $(this).val(); // Get the selected department's value
                if (selectedDept != null) {
                    $('#user-container').show(); // Show the user container
                } else {
                    $('#user-container').hide(); // Hide the user container
                }
            });


            $('#status-dropdown').change(function() {
                var selectedDeptText = $("#status-dropdown option:selected").text().toLowerCase(); // Get the text and convert to lowercase
                if (selectedDeptText.includes("resupply")) { // Check if the text includes 'resupply'
                    $('#resupplyDate-container').show();
                } else {
                    $('#resupplyDate-container').hide();
                }
            });



            $('#statusdept-dropdown').change(function() {
                var selectedDeptText1 = $("#statusdept-dropdown option:selected").text().toLowerCase(); // Get the text and convert to lowercase
                if (selectedDeptText1.includes("resupply")) { // Check if the text includes 'resupply'
                    $('#subdept-container').show();
                } else {
                    $('#subdept-container').hide();
                }
                var selectedDept = $(this).val(); // Get the selected department's value
                if (selectedDept != null) {
                    $('#user-container').show(); // Show the user container
                } else {
                    $('#user-container').hide(); // Hide the user container
                }
            });




            $('#status_id').change(function() {
                var selectedDeptText1 = $("#status_id option:selected").text().toLowerCase(); // Get the text and convert to lowercase
                if (selectedDeptText1.includes("resupply")) { // Check if the text includes 'resupply'
                    $('#resupplyDate-container').show();
                } else {
                    $('#resupplyDate-container').hide();
                }
            });




        }
        toggleMaxOrderField();
        $('#role-dropdown').change(toggleMaxOrderField);

        $('.btn-sm').on('click', function(event) {
            event.stopPropagation();
        });



        $('#dept-dropdown').change(function() {
            var deptId = $(this).val(); // Get selected department ID
            $.ajax({
                url: '/DepartmentUser/' + deptId,
                type: 'GET',
                success: function(data) {
                    var userDropdown = $('#user-dropdown');
                    userDropdown.empty(); // Remove existing options
                    userDropdown.append('<option selected disabled>Assign User</option>');
                    $.each(data, function(key, user) {
                        userDropdown.append('<option value="' + user.id + '">' +
                            user.name + '</option>');
                    });
                },
                error: function(error) {
                    console.log('Error fetching users:', error);
                }
            });
        });


        $('#statusdept-dropdown').change(function() {
            var deptId = $(this).val(); // Get selected department ID
            $.ajax({
                url: '/DepartmentUser/' + deptId,
                type: 'GET',
                success: function(data) {
                    var userDropdown = $('#user-dropdown');
                    userDropdown.empty(); // Remove existing options
                    userDropdown.append('<option selected disabled>Assign User</option>');
                    $.each(data, function(key, user) {
                        userDropdown.append('<option value="' + user.id + '">' +
                            user.name + '</option>');
                    });
                },
                error: function(error) {
                    console.log('Error fetching users:', error);
                }
            });
        });



        //Creating Logs
        //        logAction("Page Loaded: " + window.location.pathname);
    });

    $('.delete-btn').on('click', function() {
        var deleteUrl = $(this).data('url'); // Get the URL from the data attribute
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                // Send AJAX request to the delete URL
                $.ajax({
                    url: deleteUrl,
                    type: 'POST', // Match the method expected by your Laravel route
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>", // CSRF token for Laravel
                    },
                    success: function(response) {
                        Swal.fire({
                            title: "Deleted!",
                            text: "deleted Successfully.",
                            icon: "success"
                        }).then(() => {
                            window.location.reload(); // Reload the page or redirect
                        });
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                        console.error(error);
                    }
                });

                console.log(deleteUrl);
            } else {
                swalWithBootstrapButtons.fire({
                    title: "Cancelled",
                    text: "It is safe :)",
                    icon: "error"
                });
            }

        });
    });

    $('.ban-btn').on('click', function() {
        var deleteUrl = $(this).data('url'); // Get the URL from the data attribute
        Swal.fire({
            title: "Are you sure?",
            text: "You will be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, Do it!"
        }).then((result) => {
            if (result.isConfirmed) {
                // Send AJAX request to the delete URL
                $.ajax({
                    url: deleteUrl,
                    type: 'POST', // Match the method expected by your Laravel route
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>", // CSRF token for Laravel
                    },
                    success: function(response) {
                        Swal.fire({
                            title: "Success!",
                            text: "Saved Successfully.",
                            icon: "success"
                        }).then(() => {
                            window.location.reload(); // Reload the page or redirect
                        });
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                        console.error(error);
                    }
                });

            } else {
                swalWithBootstrapButtons.fire({
                    title: "Cancelled",
                    text: "It is safe :)",
                    icon: "error"
                });
            }

        });
    });


    function logAction(action) {
        $.ajax({
            url: '/log', // Ensure this URL matches your actual logging route
            type: 'POST',
            data: {
                action: action,
                _token: '<?php echo e(csrf_token()); ?>', // CSRF token for Laravel POST requests
            },
            success: function(response) {
                console.log('Action logged successfully:', action);
            },
            error: function(error) {
                console.log('Error logging action:', error);
            }
        });
    }
</script>


<?php /**PATH D:\xammp\htdocs\ecommerce-laravel\data-mangment2\resources\views/layout/footer.blade.php ENDPATH**/ ?>