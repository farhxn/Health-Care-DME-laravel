<div class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
              Created by <a target="_blank" href="farhanatif.netlify.app">M.Farhan Atif</a> with <i
                class="fa fa-heart"></i>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
              <div class="text-md-right footer-links d-none d-sm-block">
                <!-- <a href="javascript: void(0);">About</a>
                <a href="javascript: void(0);">Support</a>
                <a href="javascript: void(0);">Contact Us</a> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://colorlib.com//polygon/concept/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
  <script src="https://colorlib.com//polygon/concept/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="https://colorlib.com//polygon/concept/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
  <script src="https://colorlib.com//polygon/concept/assets/libs/js/main-js.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
</body>

</html>
<script>
  $(document).ready(function () {
      $('#myTable').DataTable();
  });

</script>
<?php /**PATH D:\xammp\htdocs\data-mangment\resources\views/layout/footer.blade.php ENDPATH**/ ?>