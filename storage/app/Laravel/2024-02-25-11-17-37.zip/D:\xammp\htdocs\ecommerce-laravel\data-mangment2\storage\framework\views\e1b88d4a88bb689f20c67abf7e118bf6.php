<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Report</title>
    <style>
        body { font-family: sans-serif; }
        .container { width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto; }
        .row { display: flex; flex-wrap: wrap; margin-right: -15px; margin-left: -15px; }
        .col-md-12 { flex: 0 0 100%; max-width: 100%; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 8px; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
        h2 { margin-top: 20px; }
    </style>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Patient Report</h2>
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>PT Name</th>
                        <th>Item</th>
                        <th>Dr. OFF.</th>
                        <th>DOB</th>
                        <th>LOCATION</th>
                        <th>INSURANCE</th>
                        <th>Status</th>
                        <th>Order Date</th>
                    </tr>
                </thead>
                <tbody>
                        <?php
                        $sno = 1;
                        ?>
                        <?php $__currentLoopData = $drs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $offName = \App\Models\Doctors::find($pt->Off_Name);
                        $statusName = \App\Models\Status::find($pt->Order_Status);
                        ?>

                        <tr onclick="window.location='/PatientDetail/<?php echo e($pt->id); ?>';">
                            <td><?php echo e($sno++); ?></td>
                            <td><?php echo e($pt->name); ?></td>
                            <td><?php echo e($pt->Item); ?></td>

                            <td><?php echo e($offName->Office_Name); ?></td>
                            <td><?php echo e($pt->Dob); ?></td>
                            <td><?php echo e($pt->Location); ?></td>
                            <td><?php echo e($pt->Insurance); ?></td>
                            <td><?php echo e($statusName->Status); ?>

                            </td>
                            <td><?php echo e($pt->created_at); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

            </table>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH D:\xammp\htdocs\ecommerce-laravel\data-mangment2\resources\views/pdf/patients.blade.php ENDPATH**/ ?>