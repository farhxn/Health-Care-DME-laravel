<?php $__env->startSection('title','Add Patient'); ?>
<?php echo $__env->make('layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="nav-left-sidebar sidebar  ">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Status</li>

                    <ul class="nav flex-column">
                        <a class="nav-link  active" href="index.html">
                            <li class="nav-item">Status 1 &nbsp; <span class="badge badge-light">( 3 )</span></li>
                        </a>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item">Status 2 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                        </a>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item">Status 3 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                        </a>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item">Status 4 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                        </a>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-1" aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Manage User</a>
                            <div id="submenu-1" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add User</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">User's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-1"><i class="fa fa-bed"></i>Manage Patients</a>
                            <div id="submenu-4" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Patient</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Patient's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-2" aria-controls="submenu-1"><i class="fa fa-building"></i>Manage Departments</a>
                            <div id="submenu-2" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Department</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Department's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-3" aria-controls="submenu-1"><i class="fa fa-hourglass-start"></i>Manage Status</a>
                            <div id="submenu-3" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Status List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-5" aria-controls="submenu-1"><i class="fa fa-stethoscope"></i>Manage Doctor</a>
                            <div id="submenu-5" class="collapse submenu" style="background-color: white;">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Add Doctor</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Doctor's List</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <a class="nav-link" href="index.html">
                            <li class="nav-item"><i class="fa fa-database"></i>Backup Database</span></li>
                        </a>
                    </ul>
                </ul>
            </div>
        </nav>
    </div>
</div>

<div class="dashboard-wrapper">
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-header">
                        <h2 class="pageheader-title ml-auto">Add Patient</h2>
                        <div class="page-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ecommerce-widget">

                <div class="row">
                    

                    <div class="col">
                        <form >
                            <?php echo csrf_field(); ?>
                        <div class="card">
                            <h5 class="card-header">Add Patient Details</h5>
                            <div class="card-body">
                                <div class="form-group">
                                    <label class="col-form-label">Patient Name</label>
                                    <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-bed"></i></span></span>
                                        <input type="text" required placeholder="Patient Name" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-form-label">Item</label>
                                    <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-flask"></i></span></span>
                                        <input type="text" required placeholder="Item" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Patient Date Of Birth</label>
                                    <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-calculator"></i></span></span>
                                        <input type="date" required placeholder="Patient Name" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Patient Address</label>
                                    <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-map"></i></span></span>
                                        <input type="text" required placeholder="Patient Address" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Patient Insurance</label>
                                    <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-info-circle"></i></span></span>
                                        <input type="text" required placeholder="Patient Insurance" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Dr. Office Name</label>
                                    <div class="input-group mb-3"><span class="input-group-prepend"><span class="input-group-text"><i class="fa fa-stethoscope"></i></span></span>
                                                <select class="form-control" required>
                                                    <option selected disabled>Dr. Office Name</option>
                                                    <option  >Dr. Office Name1</option>
                                                    <option  >Dr. Office Name2</option>
                                                    <option  >Dr. Office Name4</option>
                                                </select>

                                    </div>
                                </div>

                                <!-- <label class="col-form-label">Button Addons</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend be-addon">
                                        <button tabindex="-1" type="button" class="btn " style="background-color: #427ed1; color: white;">Dropdown</button>
                                        <button tabindex="-1" data-toggle="dropdown" type="button" class="btn dropdown-toggle dropdown-toggle-split" aria-expanded="false" style="background-color: #427ed1; color: white;"><span class="sr-only">Toggle Dropdown</span></button>
                                        <div class="dropdown-menu" x-placement="top-start" style="position: absolute; transform: translate3d(99px, -2px, 0px); top: 0px; left: 0px; will-change: transform;"><a href="#" class="dropdown-item">Action</a><a href="#" class="dropdown-item">Another action</a><a href="#" class="dropdown-item">Something else here</a>
                                            <div class="dropdown-divider"></div><a href="#" class="dropdown-item">Separated link</a>
                                        </div>
                                    </div>
                                    <input type="text" class="form-control">
                                </div> -->
                            </div>
                            <div class="card-body border-top">
                                <div class="form-group">
                                    <div class="input-group mb-3">
                                        <div class="input-group">
                                            <button type="submit" class="btn btn-block" style="background-color: #427ed1; color: white;">Submit</button>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>




            </div>
        </div>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\data-mangment\resources\views/AddPatient.blade.php ENDPATH**/ ?>