<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" />
    <link href="<?php echo e(asset('assets/vendor/fonts/circular-std/style.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/fontawesome/css/fontawesome-all.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/charts/chartist-bundle/chartist.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/charts/morris-bundle/morris.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/charts/c3charts/c3.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/flag-icon-css/flag-icon.min.css')); ?>" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" />
    <title>HEALTHCARE | <?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <div class="dashboard-main-wrapper">
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="#">HEALTHCARE</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search.." />
                            </div>
                        </li>

                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="https://colorlib.com//polygon/concept/assets/images/avatar-1.jpg" alt class="user-avatar-md rounded-circle" /></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">John Abraham</h5>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>

        <div class="nav-left-sidebar sidebar  ">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">Status</li>

                            <ul class="nav flex-column">
                                <a class="nav-link  active" href="index.html">
                                    <li class="nav-item">Status 1 &nbsp; <span class="badge badge-light">( 3 )</span></li>
                                </a>
                                <a class="nav-link" href="index.html">
                                    <li class="nav-item">Status 2 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                                </a>
                                <a class="nav-link" href="index.html">
                                    <li class="nav-item">Status 3 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                                </a>
                                <a class="nav-link" href="index.html">
                                    <li class="nav-item">Status 4 &nbsp; <span class="badge badge-light">( 13 )</span></li>
                                </a>

                            </ul>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>

        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title ml-auto"><?php echo $__env->yieldContent('dept'); ?></h2>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <!-- <li class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Home
                      </li> -->
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 1</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 2</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 3</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 4</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 5</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 6</a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 1</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 2</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 3</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 4</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 5</a>
                            </div>
                            <div class="col p-2">
                                <a href="departments.html" class="btn btn-block btn-primary">Department 6</a>
                            </div>
                        </div> <br><br>


                        <?php echo $__env->yieldContent('content'); ?>

                    </div>
                </div>
            </div>

            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            Created by <a target="_blank" href="farhanatif.netlify.app">M.Farhan Atif</a> with <i class="fa fa-heart"></i>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <!-- <a href="javascript: void(0);">About</a>
                <a href="javascript: void(0);">Support</a>
                <a href="javascript: void(0);">Contact Us</a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://colorlib.com//polygon/concept/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="https://colorlib.com//polygon/concept/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="https://colorlib.com//polygon/concept/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="https://colorlib.com//polygon/concept/assets/libs/js/main-js.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
</body>

</html>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script><?php /**PATH D:\xammp\htdocs\data-mangment\resources\views/layout/layout.blade.php ENDPATH**/ ?>