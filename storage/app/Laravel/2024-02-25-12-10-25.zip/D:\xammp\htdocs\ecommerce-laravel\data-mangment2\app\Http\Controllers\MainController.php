<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Departments;
use App\Models\Doctors;
use App\Models\Logs;
use App\Models\Notes;
use App\Models\Patients;
use App\Models\Status;
use App\Models\Users;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use Illuminate\Support\Facades\Session as FacadesSession;
use Illuminate\Support\Facades\Storage;

class MainController extends Controller
{
    public function index()
    {
        $st = Status::all();
        $dp = Departments::all();
        $userR = FacadesSession::get('LoginRole');
        $userId = FacadesSession::get('LoginId');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $drs = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  $drs->count();
        } else {
            $pt =  Patients::count();
            $drs = Patients::orderBy('created_at', 'desc')->get();
        }
        $users = Users::find($userId);
        return view('index', compact('drs', 'st', 'dp', 'pt', 'users'));
    }

    public function createAndDownloadBackup()
    {
        Artisan::call('backup:run');
        $backupPath = storage_path('app/backups');
        $backupFiles = collect(Storage::disk('local')->files('backups'))->sort()->reverse()->values();
        if ($backupFiles->isEmpty()) {
            abort(404, 'Backup file not found.');
        }
        $latestBackup = $backupFiles->first();
        dd($latestBackup);
        return response()->download($backupPath . '/' . $latestBackup);
    }


    public function PatientReport()
    {
        set_time_limit(300); // Increase to 5 minutes
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $dp = Departments::all();
        $pt =  Patients::count();
        $data = [
            'drs' => $drs,
            'st' => $st,
            'pt' => $pt,
            'dp' => $dp,
        ];
        // return view('pdf.patients',$data);
        // $pdf = Pdf::loadView('pdf.patients', $data);
        // dd($pdf);
        // return $pdf->stream();
        // return $pdf->download('PatientList.pdf');
        $pdf = PDF::loadView('pdf.patients', $data);
        // Example settings adjustments
        $pdf->setPaper('a4', 'portrait'); // Adjust paper size and orientation
        $pdf->getDomPDF()->set_option('enable_html5_parser', true); // Enable HTML5 parser for better CSS compatibility

        return $pdf->stream('PatientList.pdf');
    }


    public function FilterPatient(Request $request)
    {
        $request->validate([
            'date' => 'required',
            'status' => 'required',
        ]);
        $query = Patients::query();

        if ($request->date != "0") {
            switch ($request->date) {
                case "1":
                    $query->whereBetween('created_at', [Carbon::yesterday()->startOfDay(), now()]);
                    break;
                case "2": // Week
                    $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
                    break;
                case "3": // Month
                    $query->whereMonth('created_at', now()->month);
                    break;
                case "4":
                    $query->whereDate('created_at', now());
                    break;
            }
        }
        $query->where('Order_Status', $request->status);
        if ($request->has('dept')) {
            $query->where([['Order_Status', $request->status], ['Dept', $request->dept]]);
        } else {
            $query->where('Order_Status', $request->status);
        }

        $userR = FacadesSession::get('LoginRole');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $drs = $query->whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->count();
            $apt = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
        } else {
            $drs = $query->orderBy('created_at', 'desc')->get();
            $pt =  Patients::count();
            $apt =  Patients::All();
        }

        $st = Status::all();
        $dp = Departments::all();
        $userId = FacadesSession::get('LoginId');
        $users = Users::find($userId);
        return view('FilterdPatients', compact('drs', 'st', 'dp', 'pt', 'users', 'apt'));
    }

    public function FilterPatient2(Request $request)
    {
        $request->validate([
            'date' => 'required',
            'status' => 'required',
        ]);


        $query = Patients::query();

        if ($request->date != "0") {
            switch ($request->date) {
                case "1":
                    $query->whereBetween('created_at', [Carbon::yesterday()->startOfDay(), now()]);
                    break;
                case "2": // Week
                    $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
                    break;
                case "3": // Month
                    $query->whereMonth('created_at', now()->month);
                    break;
                case "4":
                    $query->whereDate('created_at', now());
                    break;
            }
        }
        if ($request->has('dept')) {
            $query->where([['Order_Status', $request->status], ['Dept', $request->dept]]);
        } else {
            $query->where('Order_Status', $request->status);
        }

        $userR = FacadesSession::get('LoginRole');

        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $drs = $query->whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->count();
        } else {
            $pt =  Patients::count();
            $drs = $query->orderBy('created_at', 'desc')->get();
        }

        $st = Status::all();
        $dp = Departments::all();
        $userId = FacadesSession::get('LoginId');
        $users = Users::find($userId);
        $apt =  Patients::All();
        return view('FilterdPatients', compact('drs', 'st', 'dp', 'pt', 'users', 'apt'));
    }

    public function DepartPatient($id)
    {
        $drs = Patients::where('Dept', $id)->orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $dp = Departments::all();
        $pt =  Patients::count();


        $userR = FacadesSession::get('LoginRole');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $apt = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  $apt->count();
        } else {
            $pt =  Patients::count();
            $apt = Patients::orderBy('created_at', 'desc')->get();
        }

        $userId = FacadesSession::get('LoginId');
        $users = Users::find($userId);
        $dptName = Departments::find($id);
        return view('departPatient', compact('drs', 'st', 'dp', 'pt', 'users', 'apt', 'dptName'));
    }

    public function subDept($id)
    {
        $drs = Patients::where('resupplyCat', $id)->orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $dp = Departments::all();
        $pt =  Patients::count();

        $subDeptName = $id;

        $userR = FacadesSession::get('LoginRole');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $apt = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  $apt->count();
        } else {
            $pt =  Patients::count();
            $apt = Patients::orderBy('created_at', 'desc')->get();
        }

        $userId = FacadesSession::get('LoginId');
        $users = Users::find($userId);
        return view('subdept', compact('drs', 'st', 'dp', 'pt', 'users', 'apt', 'subDeptName'));
    }

    public function ResupplyPatient($id)
    {
        $tomorrow = Carbon::tomorrow()->format('Y-m-d');
        if ($id == 0) {

            $userR = FacadesSession::get('LoginRole');
            $userId = FacadesSession::get('LoginId');
            if ($userR ==  "0") {
                $userd = FacadesSession::get('LoginDept');
                $deptIds = json_decode($userd, true);
                $drs = Patients::where('Dept', $deptIds)
                    ->whereDate('resupplyDate', $tomorrow)
                    ->orderBy('created_at', 'desc')
                    ->get();
            } else {
                $pt =  Patients::count();
                $drs = Patients::whereDate('resupplyDate', $tomorrow)
                    ->orderBy('created_at', 'desc')
                    ->get();
                $dptName = "Resupply Patients";
            }
        } else {
            $drs = Patients::where('Dept', $id)
                ->whereDate('resupplyDate', $tomorrow)
                ->orderBy('created_at', 'desc')
                ->get();
            $dptName = Departments::find($id);
        }
        $st = Status::all();
        $dp = Departments::all();
        $pt =  Patients::count();

        $userR = FacadesSession::get('LoginRole');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $apt = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  $apt->count();
        } else {
            $pt =  Patients::count();
            $apt = Patients::orderBy('created_at', 'desc')->get();
        }

        $userId = FacadesSession::get('LoginId');
        $users = Users::find($userId);

        return view('resupply', compact('drs', 'st', 'dp', 'pt', 'users', 'apt'));
    }

    public function followUpPatient($id)
    {
        $twentyFourHoursAgo = Carbon::now()->subHours(24);
        $userRole = FacadesSession::get('LoginRole');
        $userId = FacadesSession::get('LoginId');
        $dptName = "Resupply Patients"; // Default name, adjust as needed

        if ($userRole == "0") {
            $userDept = json_decode(FacadesSession::get('LoginDept'), true);
            $query = Patients::whereIn('Dept', $userDept);
        } else {
            $query = new Patients;
        }

        if ($id != 0) {
            $query = $query->where('Dept', $id);
            $department = Departments::find($id);
            $dptName = $department ? $department->name : "Department not found";
        }

        $drs = $query->where('updated_at', '>', $twentyFourHoursAgo)
            ->orderBy('created_at', 'desc')
            ->get();

        $apt = ($userRole == "0") ? $query->get() : Patients::orderBy('created_at', 'desc')->get();
        $pt = $apt->count();
        $st = Status::all();
        $dp = Departments::all();
        $users = Users::find($userId);

        return view('followup', compact('drs', 'st', 'dp', 'pt', 'users', 'apt', 'dptName'));
    }


    public function StatusPatient($id)
    {
        $userR = FacadesSession::get('LoginRole');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $drs = Patients::whereIn('Dept', $deptIds)->where('Order_Status', $id)->orderBy('created_at', 'desc')->get();
            $apt = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $pt =  $apt->count();
        } else {
            $pt =  Patients::count();
            $drs = Patients::where('Order_Status', $id)->orderBy('created_at', 'desc')->get();
            $apt =  Patients::All();
        }
        $st = Status::all();
        $stName = Status::find($id);
        $dp = Departments::all();

        $userId = FacadesSession::get('LoginId');
        $users = Users::find($userId);
        return view('StatusPatient', compact('stName', 'drs', 'st', 'dp', 'pt', 'users', 'apt'));
    }


    // Patient Section Starts

    public function AddPatient()
    {
        $st = Status::all();
        $dr = Doctors::all();
        $us = Users::all();
        $dp = Departments::all();

        $drs = Patients::orderBy('created_at', 'desc')->get();

        $pt =  Patients::count();
        return view('AddPatient', compact('st', 'dr', 'us', 'dp', 'drs', 'pt'));
    }


    public function DepartmentUser($deptId)
    {
        $users = Users::whereJsonContains('Dept', "$deptId")->get(['id', 'name']);
        return response()->json($users);
    }


    public function editPatient($id)
    {
        $pt = Patients::find($id);
        $st = Status::all();
        $dr = Doctors::all();
        $us = Users::all();
        $dp = Departments::all();
        return view('editPatient', compact('pt', 'st', 'dr', 'us', 'dp'));
    }


    public function PatientDetail($id)
    {
        // $drs = Patients::all();
        $pt = Patients::find($id);
        $act = Activity::where('PtId', $id)->orderBy('created_at', 'desc')->get();
        $not = Notes::where('PtId', $id)->orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $dp = Departments::all();


        $userR = FacadesSession::get('LoginRole');
        if ($userR ==  "0") {
            $userd = FacadesSession::get('LoginDept');
            $deptIds = json_decode($userd, true);
            $apt = Patients::whereIn('Dept', $deptIds)->orderBy('created_at', 'desc')->get();
            $tp =  $apt->count();
        } else {
            $tp =  Patients::count();
            $apt =  Patients::All();
        }

        return view('PatientDetail', compact('pt', 'not', 'st', 'dp', 'apt', 'tp', 'act'));
    }


    public function PatientList()
    {
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $dp = Departments::all();
        $pt =  Patients::count();
        return view('PatientList', compact('drs', 'st', 'dp', 'pt'));
    }

    public function UpdatePatient($id, Request $request)
    {
        $ac = new Activity();
        $st = Patients::find($id);
        $selectedStatusId = $request->input('st');
        $selectedStatus = Status::firstWhere('id', $selectedStatusId);
        if (($st->Order_Status != $request->st) || ($st->Dept != $request->dpt)) {

            $ac->name = FacadesSession::get('LoginName');
            $ac->PtId = $id;

            if ($st->Dept != $request->dpt) {
                $selectedDeptId = $request->input('dpt');
                $selectedSubDept = Departments::find($selectedDeptId);
                if ($selectedSubDept && str_contains(strtolower($selectedSubDept->Department), 'resupply')) {
                    $st = Patients::find($id);
                    $st->resupplyCat = $request->subdpt;
                    $st->updated_at = date('Y-m-d H:i:s');
                    $st->save();
                    $st = Patients::find($id);
                } else {
                    $st->resupplyCat = null;
                }

                if ($request->has('user')) {
                    $st = Patients::find($id);
                    $st->User = $request->user;
                    $st->updated_at = date('Y-m-d H:i:s');
                    $st->save();
                    $st = Patients::find($id);
                } else {
                    $selectedDeptId = $request->input('dpt');
                    $users = Users::all();
                    $usersInDept = $users->filter(function ($user) use ($selectedDeptId) {
                        $departments = json_decode($user->Dept, true); // Assuming 'departments' is the column name.
                        if (!is_array($departments)) {
                            $departments = []; // Ensure $departments is always an array.
                        }
                        return in_array($selectedDeptId, $departments);
                    });

                    $userPatientCounts = [];

                    foreach ($usersInDept as $user) {
                        $patientCount = Patients::where('Dept', $selectedDeptId)->where('User', $user->id)->count();
                        $userPatientCounts[$user->id] = $patientCount;
                    }

                    if (!empty($userPatientCounts)) {
                        $minCount = min($userPatientCounts);
                        $usersWithMinCount = array_keys($userPatientCounts, $minCount);
                        $userIdWithLeastPatients = $usersWithMinCount[array_rand($usersWithMinCount)];
                        $pt = Patients::find($id);
                        $pt->User = $userIdWithLeastPatients;
                        $st->updated_at = date('Y-m-d H:i:s');
                        $pt->save();
                    } else {
                        return back()->with('fail', '');
                    }
                }

                $pre = Departments::find($st->Dept);
                $ne = Departments::find($request->dpt);
                $ac->message = "Change Department From " . $pre->Department . " to " . $ne->Department;
                $st->updated_at = date('Y-m-d H:i:s');
                $ac->save();

                $ac = new Activity();
                $ac->PtId = $id;
                $ac->name = FacadesSession::get('LoginName');
            }

            if ($st->Order_Status != $request->st) {
                $selectedStatusId = $request->input('st');
                $selectedStatus = Status::firstWhere('id', $selectedStatusId);

                if ($selectedStatus && str_contains(strtolower($selectedStatus->Status), 'resupply')) {
                    $request->validate([
                        'redate' => 'required',
                    ]);
                    $st->resupplyDate  = $request->redate;
                } else {
                    $st->resupplyDate = null;
                }
                $pre = Status::find($st->Order_Status);
                $ne = Status::find($request->st);
                $ac->message = "Change Status From " . $pre->Status . " to " . $ne->Status;
                $ac->save();
            }

            $st->Order_Status = $request->st;
            $st->Dept = $request->dpt;
            $st->updated_at = date('Y-m-d H:i:s');
            $st->save();
            $userR = FacadesSession::get('LoginRole');
            if ($userR == "0") {
                return redirect('/');
            } else {

                return back()->with('success', '');
            }
        } elseif ($selectedStatus && str_contains(strtolower($selectedStatus->Status), 'resupply')) {
            $validatedData = $request->validate([
                'redate' => 'required',
            ]);

            $st->resupplyDate = $validatedData['redate'];
            $st->updated_at = date('Y-m-d H:i:s');
            $st->save();
            return back()->with('success', '');
        } elseif ($selectedStatus && !str_contains(strtolower($selectedStatus->Status), 'resupply')) {
            $st->resupplyDate = null;
            $st->updated_at = date('Y-m-d H:i:s');
            $st->save();
            return back()->with('success', '');
        }
        return back();
    }


    public function EditPatientDetail($id, Request $request)
    {
        $request->validate([
            'item' => 'required',
            'DOB' => 'required',
            'address' => 'required',
            'insurance' => 'required',
            'office_name' => 'required',
            'order_status' => 'required',
            'department' => 'required',
            'user' => 'required',
            'name' => 'required',
        ]);

        $st = Patients::find($id);
        $st->name = $request->name;
        $st->Item = $request->item;
        $st->Off_Name = $request->office_name;
        $st->Dob = $request->DOB;
        $st->Location = $request->address;
        $st->Insurance = $request->insurance;
        $st->Order_No = $request->orderNumber;
        $st->Order_Status = $request->order_status;
        $st->Dept = $request->department;
        $st->User = $request->user;

        if (str_contains(strtolower($request->order_status), 'resupply')) {
            $request->validate([
                'redate' => 'required',
            ]);
        }
        $st->resupplyDate = $request->redate;


        if (str_contains(strtolower($request->department), 'resupply')) {
            $request->validate([
                'subdpt' => 'required'
            ]);
        }
        $st->resupplyCat = $request->subdpt;
        $st->save();
        return redirect('PatientList')->with('success', '');
    }

    public function AddNote($id, Request $request)
    {
        $request->validate([
            'note' => 'required',
        ]);

        $no = new Notes();
        $no->name = FacadesSession::get('LoginName');
        $no->PtId = $id;
        $no->note = $request->note;
        $no->save();
        $ac = new Activity();
        $ac->PtId = $id;
        $ac->name = FacadesSession::get('LoginName');
        $ac->message = "Note Added ";
        $ac->save();
        return back()->with('success', '');
    }

    public function DeletePatient($id)
    {
        $st = Patients::find($id);
        $st->delete();
        return back();
    }

    public function RegisterPatient(Request $request)
    {
        $request->validate([
            'item' => 'required',
            'DOB' => 'required',
            'address' => 'required',
            'insurance' => 'required',
            'office_name' => 'required',
            'order_status' => 'required',
            'department' => 'required',
            'orderNumber' => 'required',
            'name' => 'required',
        ]);

        $st = new Patients();
        $st->name = $request->name;
        $st->Item = $request->item;
        $st->Off_Name = $request->office_name;
        $st->Dob = $request->DOB;
        $st->Location = $request->address;
        $st->Insurance = $request->insurance;
        $st->Order_No = $request->orderNumber;
        $st->Order_Status = $request->order_status;
        $st->Dept = $request->department;

        if (str_contains(strtolower($request->order_status), 'resupply')) {
            $request->validate([
                'redate' => 'required',
            ]);
        }
        $st->resupplyDate = $request->redate;
        if (str_contains(strtolower($request->department), 'resupply')) {
            $request->validate([
                'subdpt' => 'required',
            ]);
        }
        $st->resupplyCat = $request->subdpt;

        if ($request->has('user')) {
            $st->User = $request->user;
        } else {
            $selectedDeptId = $request->input('department');
            $users = Users::all();
            $usersInDept = $users->filter(function ($user) use ($selectedDeptId) {
                $departments = json_decode($user->Dept, true); // Assuming 'departments' is the column name.
                if (!is_array($departments)) {
                    $departments = []; // Ensure $departments is always an array.
                }
                return in_array($selectedDeptId, $departments);
            });
            $userPatientCounts = [];
            foreach ($usersInDept as $user) {
                $patientCount = Patients::where('Dept', $selectedDeptId)->where('User', $user->id)->count();
                $userPatientCounts[$user->id] = $patientCount;
            }
            if (!empty($userPatientCounts)) {
                $minCount = min($userPatientCounts);
                $usersWithMinCount = array_keys($userPatientCounts, $minCount);
                $userIdWithLeastPatients = $usersWithMinCount[array_rand($usersWithMinCount)];
                $st->User = $userIdWithLeastPatients;
            } else {
                return back()->with('fail', '');
            }
        }
        // dd($request->all());

        $st->save();
        return back()->with('success', '');
    }

    // Patient Section Ends

    // Department Section Start

    public function AddDepart()
    {
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('AddDepart', compact('drs', 'st', 'pt'));
    }

    public function editDepart($id)
    {
        $st = Departments::find($id);
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $s = Status::all();
        $pt =  Patients::count();
        return view('editDept', compact('s', 'drs', 'st', 'pt'));
    }

    public function DepartList()
    {
        $drs = Departments::orderBy('created_at', 'desc')->get();
        $dr = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('DeptList', compact('drs', 'dr', 'st', 'pt'));
    }

    public function EditDepartDetail($id, Request $request)
    {
        $request->validate([
            'Department' => 'required',
        ]);
        $st = Departments::find($id);
        $st->Department = $request->Department;
        $st->save();
        return redirect('DepartmentList')->with('success', '');
    }

    public function DeleteDepart($id)
    {
        $st = Departments::find($id);
        $st->delete();
        return back();
    }

    public function RegisterDepart(Request $request)
    {
        $request->validate([
            'Department' => 'required',
        ]);
        $st = new Departments();
        $st->Department = $request->Department;
        $st->save();
        return back()->with('success', '');
    }

    // Department Section Ends





    // Status Section Start

    public function AddStatus()
    {
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('AddStatus', compact('drs', 'st', 'pt'));
    }

    public function editStatus($id)
    {
        $st = Status::find($id);
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $s = Status::all();
        $pt =  Patients::count();

        return view('editStatus', compact('st', 'drs', 's', 'pt'));
    }

    public function StatusList()
    {
        $drs = Status::orderBy('created_at', 'desc')->get();
        $dr = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('StatusList', compact('drs', 'dr', 'st', 'pt'));
    }

    public function EditStatusDetail($id, Request $request)
    {
        $request->validate([
            'status' => 'required',
        ]);
        $st = Status::find($id);
        $st->Status = $request->status;
        $st->save();
        return redirect('StatusList')->with('success', '');
    }

    public function DeleteStatus($id)
    {
        $st = Status::find($id);
        $st->delete();
        return back();
    }

    public function RegisterStatus(Request $request)
    {
        $request->validate([
            'status' => 'required',
        ]);
        $st = new Status();
        $st->Status = $request->status;
        $st->save();
        return back()->with('success', '');
    }

    // Status Section Ends



    // Doctors Section Start

    public function AddDoctor()
    {
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('AddDoctor', compact('drs', 'st', 'pt'));
    }

    public function RegisterDoctor(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'number' => 'required',
            'fax' => 'required'
        ]);
        $dc = new Doctors();
        $dc->Office_Name = $request->name;
        $dc->Phone_Num = $request->number;
        $dc->Fax = $request->fax;
        $dc->save();
        return back()->with('success', '');
    }

    public function DoctorList()
    {
        $drs = Doctors::orderBy('created_at', 'desc')->get();
        $dr = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('doctorList', compact('drs', 'dr', 'st', 'pt'));
    }

    public function DeleteDoctor($id)
    {
        $user = Doctors::find($id);
        $user->delete();
        return back();
    }

    public function EditDoctor($id)
    {
        $dc = Doctors::find($id);
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('editDoctor', compact('dc', 'drs', 'st', 'pt'));
    }

    public function EditDoctorDetail($id, Request $request)
    {
        $request->validate([
            'name' => 'required',
            'number' => 'required',
            'fax' => 'required'
        ]);
        $dc =  Doctors::find($id);
        $dc->Office_Name = $request->name;
        $dc->Phone_Num = $request->number;
        $dc->Fax = $request->fax;
        $dc->save();
        return redirect('DoctorList')->with('success', 'You Have Registered successfully');
    }

    // Doctor Section End





    //User Section Start

    public function AddUser()
    {
        $dep = Departments::all();
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('AddUser', compact('dep', 'drs', 'st', 'pt'));
    }

    public function userDetail($id)
    {
        $user = Users::find($id);
        $drs = Patients::where('User', $id)->get('*');
        $tdpCount = Patients::where('User', $id)->whereDate('created_at', '=', now()->toDateString())->count();
        $tpCount = $drs->count();

        $dr = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();

        return view('userDetail', compact('user', 'drs', 'tpCount', 'tdpCount', 'dr', 'st', 'pt'));
    }

    public function UserList()
    {
        $users = Users::orderBy('created_at', 'desc')->get();
        // $users->each(function($user) {
        //     $user->Dept = json_decode($user->Dept, true);
        // });
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('userList', compact('users', 'drs', 'st', 'pt'));
    }

    public function EditUser($id)
    {
        $user = Users::find($id);
        $dep = Departments::all();
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('editUser', compact('user', 'dep', 'drs', 'st', 'pt'));
    }

    public function RegisterUser(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'role' => 'required',
            'mail' => 'required|email|unique:users,email',
            'password' => 'required|min:8|max:12'
        ]);
        $user = new Users();
        $user->name = $request->name;
        $user->email = $request->mail;
        $user->role = $request->role;
        if ($request->role == "0") {
            $user->max_pending_order = $request->max_order;
            $user->Dept = json_encode($request->dept);
        }
        $user->password = Hash::make($request->password);
        $user->save();
        return back()->with('success', 'You Have Registered successfully');
    }

    public function EditUserDetail($id, Request $request)
    {
        $request->validate([
            'name' => 'required',
            'role' => 'required',
            'mail' => 'required|email',
        ]);
        $user = Users::find($id);
        $user->name = $request->name;
        $user->email = $request->mail;
        $user->role = $request->role;
        if ($request->role == "0") {
            $user->max_pending_order = $request->max_order;
            $user->Dept = json_encode($request->dept);
        } else {
            $user->max_pending_order = null;
            $user->Dept = null;
        }

        $user->save();
        return redirect('UserList')->with('success', 'You Have Registered successfully');
    }

    public function DeleteUser($id)
    {
        $user = Users::find($id);
        $user->delete();
        return back();
    }

    public function BanUser($id)
    {
        $user = Users::find($id);
        if ($user->status == "1") {
            $user->status = "0";
        } else {
            $user->status = "1";
        }
        $user->save();

        return back();
    }

    //User Section Ends




    public function ChangePassword()
    {
        $drs = Patients::orderBy('created_at', 'desc')->get();
        $st = Status::all();
        $pt =  Patients::count();
        return view('changePassword', compact('drs', 'st', 'pt'));
    }


    public function OTPVerify()
    {
        return view('verifyOTP');
    }

    public function forgetPassword()
    {
        return view('forgetPassword');
    }

    public function login()
    {
        return view('login');
    }

    public function VerifyOTP(Request $request)
    {
        $request->validate([
            'otp' => 'required|min:4|max:4'
        ]);
        $userCode = FacadesSession::get('LoginCode');
        if ($request->otp == $userCode) {
            return redirect('/');
        } else {
            return back()->with('fail', 'You Have');
        }
    }

    public function LoginUser(Request $request)
    {
        $request->validate([
            'mail' => 'required|email',
            'password' => 'required|min:8|max:12'
        ]);
        $user = Users::where('email', '=', $request->mail)->first();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                if ($user->status == "0") {
                    $request->session()->put('LoginId', $user->id);
                    $request->session()->put('LoginName', $user->name);
                    $request->session()->put('LoginRole', $user->role);
                    $request->session()->put('LoginDept', $user->Dept);
                    $request->session()->put('LoginMail', $user->email);
                } else {
                    return back()->with('Ban', 'Account Banned');
                }
                return redirect('AuthMail');
            } else {
                return back()->with('fail', 'Password not match');
            }
        } else {
            return back()->with('fail', 'E-Mail not registered');
        }
        return back()->with('success', 'You Have Login successfully');
    }

    public function logout()
    {
        if (session()->has('LoginId')) {
            session()->flush();
        }
        return redirect::to('/');
    }

    public function UpdatePassword(Request $request)
    {
        $request->validate([
            'mail' => 'required|email',
        ]);

        $user = Users::where('email', '=', $request->mail)->first();
        if ($user) {
            $uniquePassword = mt_rand(10000000, 99999999);
            session()->put('NewPassowrd', $uniquePassword);
            $user->password = Hash::make($uniquePassword);
            $user->save();
            $mail = new PHPMailer(true);
            try {
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->SMTPDebug = 0; // Disable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'specificprojectmail@gmail.com';                     //SMTP username
                $mail->Password   = 'bmtfakpvvjxcvevb';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                $mail->setFrom('specificprojectmail@gmail.com', 'Farhan');
                $mail->addAddress($request->mail);
                //Content
                $mail->Subject = 'Updated Password';
                $mail->isHTML(true);
                $mail->Body = '
                <html>
                <head>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 0;
                            padding: 20px;
                            background-color: #f4f4f4;
                        }
                        .container {
                            background-color: #fff;
                            padding: 20px;
                            border-radius: 5px;
                            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                            max-width: 600px;
                            margin: 40px auto;
                            text-align: center;
                        }
                        .code {
                            font-size: 24px;
                            margin: 20px 0;
                            padding: 10px;
                            border: 1px solid #ddd;
                            background-color: #f9f9f9;
                            display: inline-block;
                            font-weight: bold;
                        }
                        .footer {
                            margin-top: 20px;
                            font-size: 12px;
                            color: #666;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h2>Your Verification Code</h2>
                        <p> Please enter the following Password to Login your Account.</p>
                        <div class="code">' . $uniquePassword . '</div>
                        <p class="footer">If you did not request this code, please ignore this email.</p>
                    </div>
                </body>
                </html>';


                $mail->send();
                echo 'Message has been sent';
            } catch (Exception $e) {
                // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
            return redirect('Login');
        } else {
            return back()->with('fail', '');
        }
    }

    public function UpdateChangePassword(Request $request)
    {
        $request->validate([
            'password' => 'required|min:8|max:12'
        ]);
        $userId = FacadesSession::get('LoginId');
        $user = Users::find($userId);
        $user->password = Hash::make($request->password);
        $user->save();
        return back()->with('success', '');
    }

    public function AuthenticationMail()
    {
        $mail = new PHPMailer(true);
        try {
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->SMTPDebug = 0; // Disable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'specificprojectmail@gmail.com';                     //SMTP username
            $mail->Password   = 'bmtfakpvvjxcvevb';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            $userMail = FacadesSession::get('LoginMail');

            $mail->setFrom('specificprojectmail@gmail.com', 'Farhan');
            $mail->addAddress($userMail);

            //Content
            $mail->Subject = 'Verification Code';
            $mail->isHTML(true);
            $code = mt_rand(1000, 9999);
            session()->put('LoginCode', $code);
            $mail->Body = '
            <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background-color: #f4f4f4;
                    }
                    .container {
                        background-color: #fff;
                        padding: 20px;
                        border-radius: 5px;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                        max-width: 600px;
                        margin: 40px auto;
                        text-align: center;
                    }
                    .code {
                        font-size: 24px;
                        margin: 20px 0;
                        padding: 10px;
                        border: 1px solid #ddd;
                        background-color: #f9f9f9;
                        display: inline-block;
                        font-weight: bold;
                    }
                    .footer {
                        margin-top: 20px;
                        font-size: 12px;
                        color: #666;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Your Verification Code</h2>
                    <p>Thank you for registering. Please enter the following verification code to complete your registration process.</p>
                    <div class="code">' . $code . '</div>
                    <p class="footer">If you did not request this code, please ignore this email.</p>
                </div>
            </body>
            </html>';


            $mail->send();
            echo 'Message has been sent';
        } catch (Exception $e) {
            // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
        return Redirect('OTPVerify')->with('success', 'You Have Registered successfully');
    }

    public function store(Request $request)
    {
        $userId = FacadesSession::get('LoginId');
        $userName = FacadesSession::get('LoginName');
        $log = new Logs();
        $log->Action = $request->action;
        $log->UserId = FacadesSession::get('LoginId');
        $log->UserName = FacadesSession::get('LoginName');
        $log->save();
        return response()->json(['success' => 'Action logged successfully']);
    }
}
